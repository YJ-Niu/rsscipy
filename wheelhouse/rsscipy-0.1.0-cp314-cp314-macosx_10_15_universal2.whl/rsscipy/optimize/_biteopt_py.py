from collections.abc import Callable, Iterable
from typing import Concatenate

import rsnumpy as np
from rsscipy.optimize._optimize import OptimizeResult
from ._constraints import old_bound_to_new, Bounds
from ._biteopt import minimize as _minimize  # type: ignore[import-not-found]
from rsscipy._lib._util import _validate_int

__all__ = ['biteopt']


def biteopt(
    func: Callable[Concatenate[np.ndarray, ...], float],
    bounds: Iterable | Bounds,
    *,
    args: tuple = (),
    callback: Callable[[np.ndarray], object] | None = None,
    maxfun: int | None = None,
    depth: int = 1,
    f_min: float = -np.inf,
    rng: int | np.random.Generator | None = None,
):
    """Find the global minimum of a function using the BiteOpt algorithm.

    Parameters
    ----------
    func : callable
        The objective function to be minimized, ``func(x, *args) -> float``,
        where ``x`` is a 1-D array with shape ``(n,)`` and ``args`` is a tuple
        of fixed parameters.
    bounds : sequence or `Bounds`
        Bounds for variables, specified either as an instance of `Bounds` or as
        ``(min, max)`` pairs for each element in ``x``. Bounds must be finite
        and satisfy ``min < max`` strictly for every variable; equal bounds
        (fixing a variable) are not accepted.
    args : tuple, optional
        Additional fixed parameters passed to the objective function.
    callback : callable, optional
        Called after each objective evaluation as ``callback(x)``, where ``x``
        is the point that was just evaluated. If the callback raises
        `StopIteration`, the optimization stops early and returns with
        ``success=False``.
    maxfun : int, optional
        Maximum number of objective function evaluations. Default is
        ``1000 * n``, where ``n`` is the number of variables inferred from
        ``bounds``.
    depth : int, optional
        Number of BiteOpt instances run cooperatively.
        Whenever one instance finds an improved solution, that solution is
        injected into another randomly chosen instance for further refinement.
        This cooperative multi-instance strategy improves the chance of escaping
        local minima on complex, multi-modal functions but requires a
        larger function evaluation budget. Valid range is ``[1, 36]``.
        Default is 1.
    f_min : float, optional
        Target objective value. The optimization stops early once the best
        objective value found is less than or equal to `f_min`. By default
        (-inf) this criterion is disabled and the full iteration budget is
        used.
    rng : {None, int, `rsnumpy.random.Generator`}, optional
        Controls reproducibility. Passed to `rsnumpy.random.default_rng`; the
        resulting Generator's bit stream directly drives BiteOpt's internal
        random draws.

    Returns
    -------
    res : OptimizeResult
        The optimization result represented as an `OptimizeResult` object.
        Important attributes are: ``x`` the solution array, ``fun`` the value
        of the objective at the solution, ``nfev`` the number of objective
        evaluations performed, ``success`` a boolean flag indicating whether
        the optimizer terminated successfully, and ``message`` describing the
        cause of termination. When `f_min` is set to a value greater than
        -inf, ``success`` is ``True`` only if that target was reached. If
        `f_min` is -inf (the default), BiteOpt runs its full iteration
        budget and a completed run reports ``success`` as ``True``.

    Notes
    -----
    BiteOpt (BITmask Evolution OPTimization) is a stochastic, population-based,
    global optimizer that maintains a portfolio of candidate-generation strategies
    and dynamically tracks their efficiency, favouring whichever works best for
    the current objective function. This contrasts with classical
    Differential Evolution, which uses a single fixed strategy throughout [1]_.

    BiteOpt targets low- to medium-dimensional continuous problems with finite box
    bounds and requires no gradient information. Because the search is
    stochastic, results depend on the random stream; pass `rng` for
    reproducible runs. BiteOpt has proven to be very competitive especially
    for nonlinear least squares problems [2]_.

    The lock of the Generator derived from `rng` is held for the duration of
    the optimization. Drawing from the same Generator inside `func` is safe.

    .. versionadded:: 2.0.0

    References
    ----------
    .. [1] Aleksey Vaneev. "BiteOpt - Derivative-Free Global Optimization
           Method (C++)". https://github.com/avaneev/biteopt
    .. [2] Andrea Gavana. "NIST benchmark".
           https://infinity77.net/go_2021/nist.html

    Examples
    --------
    The following example is a 2-D problem with four local minima: minimizing
    the Styblinski-Tang function
    (https://en.wikipedia.org/wiki/Test_functions_for_optimization).

    >>> from rsscipy.optimize import biteopt, Bounds
    >>> def styblinski_tang(pos):
    ...     x, y = pos
    ...     return 0.5 * (x**4 - 16*x**2 + 5*x + y**4 - 16*y**2 + 5*y)
    >>> bounds = Bounds([-4., -4.], [4., 4.])
    >>> result = biteopt(styblinski_tang, bounds)
    >>> result.x, result.fun, result.nfev
    array([-2.90353406, -2.90353401]), -78.3323279095383, 2000  # may vary

    For reproducible results, pass a seed to `rng`:

    >>> result = biteopt(styblinski_tang, bounds, rng=1)
    >>> result.x, result.fun, result.nfev
    array([-2.90353402, -2.90353405]), -78.33233140754281, 2000

    To stop the optimization early once a target objective value is reached,
    pass `f_min`:

    >>> result = biteopt(styblinski_tang, bounds, f_min=-70, rng=1)
    >>> result.x, result.fun, result.nfev
    array([-2.67348466, -2.67348466]), -76.64070151847848, 38
    """
    if not callable(func):
        raise TypeError("func must be callable")
    if callback is not None and not callable(callback):
        raise TypeError("callback must be callable")

    if not isinstance(bounds, Bounds):
        try:
            lb, ub = old_bound_to_new(bounds)
            bounds = Bounds(lb, ub)
        except (TypeError, ValueError) as e:
            raise ValueError(
                "bounds must be a sequence of (min, max) pairs or "
                "instance of Bounds class"
            ) from e

    lb = np.ascontiguousarray(bounds.lb, dtype=np.float64)
    ub = np.ascontiguousarray(bounds.ub, dtype=np.float64)

    if lb.ndim != 1:
        raise ValueError("bounds must be one-dimensional")
    if not np.all(lb < ub):
        raise ValueError("Bounds are not consistent min < max")
    if np.any(np.isinf(lb)) or np.any(np.isinf(ub)):
        raise ValueError("Bounds must not be inf.")

    depth = _validate_int(depth, "depth", minimum=1, maximum=36)

    if maxfun is not None:
        # The iteration count is passed to the C++ layer as a C ``int``; reject
        # oversized values here for a clear error
        max_allowed_int = np.iinfo(np.intc).max
        maxfun = _validate_int(maxfun, "maxfun", minimum=1, maximum=max_allowed_int)
    else:
        ndim = len(lb)
        maxfun = 1000 * ndim

    f_min = float(f_min)
    if np.isnan(f_min):
        raise ValueError("f_min must not be NaN")

    # BiteOpt's internal PRNG is driven by the NumPy Generator's bit
    # generator. Keep a reference to ``generator`` alive for the duration of
    # the call so its capsule pointer stays valid.
    generator = np.random.default_rng(rng)

    def func_wrap(x):
        fx = func(x, *args)
        if not np.isscalar(fx):
            _dt = getattr(fx, "dtype", np.dtype(np.float64))
            try:
                fx = _dt.type(np.asarray(fx).item())
            except (TypeError, ValueError, AttributeError) as e:
                raise ValueError(
                    "The user-provided objective function "
                    "must return a scalar value."
                ) from e
        return fx

    # naming convention: SciPy's "maxfun" is BiteOpt's "iter"
    # BiteOpt internally scales iter by sqrt(depth): useiter = int(iter * sqrt(depth)).
    # Pre-divide so the actual evaluation count never exceeds maxfun.
    # floor(maxfun / sqrt(depth)) guarantees no overshoot; then probe floor+1
    # to squeeze in one more iteration if it still fits within the budget.
    _sqrt = np.sqrt(depth)
    _iter = int(maxfun / _sqrt)
    if int((_iter + 1) * _sqrt) <= maxfun:
        _iter += 1
    # Even a single iteration costs int(sqrt(depth)) evaluations. If that already
    # exceeds maxfun, _iter is 0; clamping it up to 1 would overshoot the budget,
    # so refuse instead of silently exceeding maxfun.
    if _iter < 1:
        raise ValueError(
            f"maxfun={maxfun} is too small for depth={depth}; maxfun must be "
            f"at least {int(_sqrt)} for this depth."
        )

    # Hold the bit generator's lock for the whole optimization. The C extension
    # draws from this bit generator through a lock-free adapter. On a default
    # build the GIL already serializes those draws, but on a free-threaded build
    # it does not, so taking the lock here prevents a data race if the *same*
    # generator is used concurrently from another thread (NumPy's own Generator
    # methods acquire this same lock). It is uncontended in the common case where
    # ``generator`` was freshly created above.
    with generator.bit_generator.lock:
        result = _minimize(
            func_wrap,
            lb,
            ub,
            _iter,
            int(depth),
            1, # only one attempt, the best result is returned
            generator.bit_generator.capsule,
            f_min,
            callback,
        )

    if result.get("callback_stopped", False):
        return OptimizeResult(
            x=np.asarray(result["x"]),
            fun=result["fun"],
            nfev=result["nfev"],
            success=False,
            status=99,
            message="`callback` raised `StopIteration`.",
        )

    # BiteOpt is a fixed-budget stochastic optimizer. Its only intrinsic success
    # criterion is the early-stop target `f_min`, which it reaches exactly when
    # the best value satisfies ``fun <= f_min``. Absent `f_min` there is no
    # reliable convergence test (biteopt typically keeps making small improving
    # steps until the iteration budget is exhausted), so a completed run is
    # reported as successful.
    if f_min == -np.inf:
        success = True
        status = 0
        message = "Maximum number of function evaluations reached."
    else:
        if result["fun"] <= f_min:
            success = True
            status = 0
            message = "Optimization terminated successfully: f_min reached."
        else:
            success = False
            status = 1
            message = ("Maximum number of function evaluations reached; "
                       "f_min not reached.")

    return OptimizeResult(
        x=np.asarray(result["x"]),
        fun=result["fun"],
        nfev=result["nfev"],
        success=success,
        status=status,
        message=message,
    )
