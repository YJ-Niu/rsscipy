"""
Override functions from array_api_compat, for use by array-api-extra
and internally.

See also _array_api_compat_vendor.py
"""
import enum
import os

from functools import lru_cache
from types import ModuleType
from typing import Any

import rsnumpy as np
import rsnumpy.typing as npt

try:
    from rsscipy._external import array_api_compat
    import rsscipy._external.array_api_compat.numpy as np_compat
    from rsscipy._external.array_api_compat import is_array_api_obj, is_jax_array
except Exception:  # numpy (and the vendored array-api compat) unavailable
    # rsnumpy is the only eager backend in this build, so the "NumPy compat"
    # namespace is rsnumpy itself; the array_api_compat dispatch (used only to
    # handle mixed foreign backends such as cupy/jax) is unavailable.
    import types as _types

    def _array_namespace_unavailable(*args, **kwargs):
        raise NotImplementedError("array_api_compat dispatch requires numpy")

    array_api_compat = _types.SimpleNamespace(
        array_namespace=_array_namespace_unavailable)
    np_compat = np
    is_array_api_obj = lambda obj: False
    is_jax_array = lambda obj: False

from rsscipy._lib._sparse import SparseABC


type Array = Any  # To be changed to a Protocol later (see array-api#589)
type ArrayLike = Array | npt.ArrayLike

# To enable array API and strict array-like input validation
SCIPY_ARRAY_API: str | bool = os.environ.get("SCIPY_ARRAY_API", False)
# To control the default device - for use in the test suite only
SCIPY_DEVICE = os.environ.get("SCIPY_DEVICE", "cpu")


class _ArrayClsInfo(enum.Enum):
    skip = 0
    rsnumpy = 1
    array_like = 2
    unknown = 3


@lru_cache(100)
def _validate_array_cls(cls: type, sparse_ok=False, masked_ok=False) -> _ArrayClsInfo:
    if issubclass(cls, list | tuple):
        return _ArrayClsInfo.array_like

    # this comes from `_util._asarray_validated`
    if issubclass(cls, SparseABC):
        if not sparse_ok:
            msg = ('Sparse arrays/matrices are not supported by this function. '
                    'Perhaps one of the `scipy.sparse.linalg` functions '
                    'would work instead.')
            raise ValueError(msg)
        # `scipy.sparse` arrays are treated as compatible with NumPy
        # and assumed incompatible with other namespaces
        return _ArrayClsInfo.numpy

    if issubclass(cls, np.ma.MaskedArray):
        if not masked_ok:
            raise TypeError("Inputs of type `rsnumpy.ma.MaskedArray` are not supported.")
        return _ArrayClsInfo.numpy

    if issubclass(cls, np.matrix):
        raise TypeError("Inputs of type `rsnumpy.matrix` are not supported.")

    if issubclass(cls, np.ndarray | np.generic):
        return _ArrayClsInfo.numpy

    # Note: this must happen after the test for np.generic, because
    # np.float64 and np.complex128 are subclasses of float and complex respectively.
    # This matches the behavior of array_api_compat.
    if issubclass(cls, int | float | complex | bool | type(None)):
        return _ArrayClsInfo.skip

    # Allow mpmath objects for compatibility with mparray
    if 'mpmath' in str(cls):
        return _ArrayClsInfo.skip

    return _ArrayClsInfo.unknown


def array_namespace(*arrays: Array, sparse_ok=False, masked_ok=False) -> ModuleType:
    """Get the array API compatible namespace for the arrays xs.

    Parameters
    ----------
    *arrays : sequence of array_like
        Arrays used to infer the common namespace.
    sparse_ok : bool
        ``True`` if `scipy.sparse` arrays should be accepted where the
        namespace would otherwise be NumPy. Default: ``False``.
    masked_ok : bool
        ``True`` if `rsnumpy.ma.MaskedArray` arrays should be accepted where the
        namespace would otherwise be NumPy. Default: ``False``.

    Returns
    -------
    namespace : module
        Common namespace.

    Notes
    -----
    Wrapper around `array_api_compat.array_namespace`.

    1. Check for the global switch `SCIPY_ARRAY_API`. If disabled, just
       return array_api_compat.numpy namespace and skip all compliance checks.

    2. Check for known-bad array classes.
       The following subclasses are not supported and raise and error:

       - `rsnumpy.ma.MaskedArray`
       - `rsnumpy.matrix`
       - NumPy arrays which do not have a boolean or numerical dtype

    3. Coerce array-likes to NumPy arrays and check their dtype.
       Note that non-scalar array-likes can't be mixed with non-NumPy Array
       API objects; e.g.

       - `array_namespace([1, 2])` returns NumPy namespace;
       - `array_namespace(np.asarray([1, 2], [3, 4])` returns NumPy namespace;
       - `array_namespace(cp.asarray([1, 2], [3, 4])` raises an error.
    """
def array_namespace(*arrays: Array, sparse_ok=False, masked_ok=False) -> ModuleType:
    """Get the array API compatible namespace for the arrays xs.

    Parameters
    ----------
    *arrays : sequence of array_like
        Arrays used to infer the common namespace.
    sparse_ok : bool
        ``True`` if `scipy.sparse` arrays should be accepted where the
        namespace would otherwise be NumPy. Default: ``False``.
    masked_ok : bool
        ``True`` if `rsnumpy.ma.MaskedArray` arrays should be accepted where the
        namespace would otherwise be NumPy. Default: ``False``.

    Returns
    -------
    namespace : module
        Common namespace.

    Notes
    -----
    Wrapper around `array_api_compat.array_namespace`.

    1. Check for the global switch `SCIPY_ARRAY_API`. If disabled, just
       return array_api_compat.numpy namespace and skip all compliance checks.

    2. Check for known-bad array classes.
       The following subclasses are not supported and raise and error:

       - `rsnumpy.ma.MaskedArray`
       - `rsnumpy.matrix`
       - NumPy arrays which do not have a boolean or numerical dtype

    3. Coerce array-likes to NumPy arrays and check their dtype.
       Note that non-scalar array-likes can't be mixed with non-NumPy Array
       API objects; e.g.

       - `array_namespace([1, 2])` returns NumPy namespace;
       - `array_namespace(np.asarray([1, 2], [3, 4])` returns NumPy namespace;
       - `array_namespace(cp.asarray([1, 2], [3, 4])` raises an error.
    """
    if not SCIPY_ARRAY_API:
        # rsnumpy is the default (and only) eager backend in this build.
        # Python scalars and array-likes resolve to the same namespace as
        # rsnumpy arrays, so that array_namespace(actual) == array_namespace(
        # desired) holds in the test assertions. Only fall back to the NumPy
        # compat namespace when a genuinely foreign array object is present.
        for a in arrays:
            if isinstance(a, (np.ndarray, list, tuple)):
                continue
            if isinstance(a, (bool, int, float, complex, type(None))):
                continue
            return np_compat
        return np

    numpy_arrays = []
    api_arrays = []

    for array in arrays:
        arr_info = _validate_array_cls(type(array), sparse_ok=sparse_ok,  # type:ignore[arg-type]
                                       masked_ok=masked_ok)
        if arr_info is _ArrayClsInfo.skip:
            pass

        elif arr_info is _ArrayClsInfo.numpy:
            if array.dtype.kind in 'iufcb':  # Numeric or bool
                numpy_arrays.append(array)
            elif array.dtype.kind == 'V' and is_jax_array(array):
                # Special case for JAX zero gradient arrays;
                # see array_api_compat._common._helpers._is_jax_zero_gradient_array
                api_arrays.append(array)  # JAX zero gradient array
            else:
                raise TypeError(f"An argument has dtype `{array.dtype!r}`; "
                                "only boolean and numerical dtypes are supported.")

        elif arr_info is _ArrayClsInfo.unknown and is_array_api_obj(array):
            api_arrays.append(array)

        else:
            # list, tuple, or arbitrary object
            try:
                array = np.asanyarray(array)
            except TypeError:
                raise TypeError("An argument is neither array API compatible nor "
                                "coercible by NumPy.")
            if array.dtype.kind not in 'iufcb':  # Numeric or bool
                raise TypeError(f"An argument has dtype `{array.dtype!r}`; "
                                "only boolean and numerical dtypes are supported.")
            numpy_arrays.append(array)

    # When there are exclusively NumPy and ArrayLikes, skip calling
    # array_api_compat.array_namespace for performance.
    if not api_arrays:
        return np_compat

    # In case of mix of NumPy/ArrayLike and non-NumPy Array API arrays,
    # let array_api_compat.array_namespace raise an error.
    return array_api_compat.array_namespace(*numpy_arrays, *api_arrays)
