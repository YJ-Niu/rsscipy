import sys
from collections.abc import Callable, Iterator
from types import ModuleType
from typing import Any, cast, final

import numpy as np
import pytest
from typing_extensions import override

from array_api_extra._lib._backends import Backend
from array_api_extra._lib._compat import (
    array_namespace,
    is_dask_namespace,
    is_jax_namespace,
)
from array_api_extra._lib._typing import Array, ArrayNamespace, Device
from array_api_extra.testing import (
    assert_close,
    assert_close_nulp,
    assert_equal,
    assert_less,
    lazy_xp_function,
    patch_lazy_xp_functions,
)
from array_api_extra.testing._testing import _as_numpy_array

# pyright: reportUnknownParameterType=false,reportMissingParameterType=false


class TestAsNumPyArray:
    def test_basic(self, xp: ArrayNamespace):
        x = xp.asarray([1, 2, 3])
        y = _as_numpy_array(x, xp=xp)
        assert_equal(y, np.asarray([1, 2, 3]))  # type: ignore[arg-type]  # pyright: ignore[reportArgumentType]

    @pytest.mark.skip_xp_backend(Backend.TORCH, reason="materialize 'meta' device")
    def test_device(self, xp: ArrayNamespace, device: Device):
        x = xp.asarray([1, 2, 3], device=device)
        y = _as_numpy_array(x, xp=xp)
        assert_equal(y, np.asarray([1, 2, 3]))  # type: ignore[arg-type]  # pyright: ignore[reportArgumentType]


class TestAssertEqualCloseLess:
    def np_err_msg(self, func: object):
        return "not equal" if func is assert_close_nulp else "Mismatched elements"

    @pytest.mark.parametrize("func", [assert_equal, assert_close])
    def test_assert_equal_close_basic(
        self, xp: ArrayNamespace, func: Callable[..., None]
    ):
        func(xp.asarray(0), xp.asarray(0))
        func(xp.asarray([1, 2]), xp.asarray([1, 2]))

        with pytest.raises(AssertionError, match="Mismatched elements"):
            func(xp.asarray([1, 2]), xp.asarray([2, 1]))

        with pytest.raises(AssertionError, match="hello"):
            func(xp.asarray([1, 2]), xp.asarray([2, 1]), err_msg="hello")

    @pytest.mark.parametrize(
        "func", [assert_equal, assert_close, assert_less, assert_close_nulp]
    )
    def test_shape_dtype(self, xp: ArrayNamespace, func: Callable[..., None]):
        with pytest.raises(AssertionError, match="shapes do not match"):
            func(xp.asarray([0]), xp.asarray([[0]]))

        with pytest.raises(AssertionError, match="dtypes do not match"):
            func(xp.asarray(0, dtype=xp.float32), xp.asarray(0, dtype=xp.float64))

    @pytest.mark.skip_xp_backend(Backend.NUMPY, reason="test other ns vs. numpy")
    @pytest.mark.skip_xp_backend(
        Backend.NUMPY_READONLY, reason="test other ns vs. numpy"
    )
    @pytest.mark.parametrize(
        "func", [assert_equal, assert_close, assert_less, assert_close_nulp]
    )
    def test_namespace(self, xp: ArrayNamespace, func: Callable[..., None]):
        with pytest.raises(
            AssertionError, match="Namespaces of actual and desired arrays do not match"
        ):
            func(xp.asarray(0), np.asarray(0))
        with pytest.raises(TypeError, match=r"array_namespace requires .* array input"):
            func(xp.asarray(0), 0)
        with pytest.raises(TypeError, match="list is not a supported array type"):
            func(xp.asarray([0]), [0])
        func(xp.asarray(0), xp.asarray(1 if func is assert_less else 0), xp=xp)
        with (
            pytest.raises(
                AssertionError,
                match="Namespace of actual array does not match the `xp` argument",
            ),
        ):
            func(xp.asarray(0), xp.asarray(0), xp=np)

    @pytest.mark.parametrize(
        "func", [assert_equal, assert_close, assert_less, assert_close_nulp]
    )
    def test_check_shape(self, xp: ArrayNamespace, func: Callable[..., None]):
        a = xp.asarray([1] if func is assert_less else [2])
        b = xp.asarray(2)
        c = xp.asarray(0)
        d = xp.asarray([2, 2])

        with pytest.raises(AssertionError, match="shapes do not match"):
            func(a, b)
        func(a, b, check_shape=False)
        with pytest.raises(AssertionError, match=self.np_err_msg(func)):
            func(a, c, check_shape=False)
        with pytest.raises(AssertionError, match="sizes do not match"):
            func(a, d, check_shape=False)

    @pytest.mark.parametrize(
        "func", [assert_equal, assert_close, assert_less, assert_close_nulp]
    )
    def test_check_dtype(self, xp: ArrayNamespace, func: Callable[..., None]):
        a = xp.asarray(1 if func is assert_less else 2)
        b = xp.asarray(2, dtype=xp.int16)
        c = xp.asarray(0, dtype=xp.int16)

        with pytest.raises(AssertionError, match="dtypes do not match"):
            func(a, b)
        func(a, b, check_dtype=False)
        with pytest.raises(AssertionError, match=self.np_err_msg(func)):
            func(a, c, check_dtype=False)

    @pytest.mark.parametrize(
        "func", [assert_equal, assert_close, assert_less, assert_close_nulp]
    )
    @pytest.mark.xfail_xp_backend(
        Backend.SPARSE, reason="sparse [()] returns np.generic"
    )
    def test_check_scalar(
        self, xp: ArrayNamespace, library: Backend, func: Callable[..., None]
    ):
        a = xp.asarray(1 if func is assert_less else 2)
        b = xp.asarray(2)[()]  # Note: only makes a difference on NumPy
        c = xp.asarray(0)

        func(a, b)
        if library.like(Backend.NUMPY):
            with pytest.raises(AssertionError, match="array-ness does not match"):
                func(a, b, check_scalar=True)
        else:
            func(a, b, check_scalar=True)
        with pytest.raises(AssertionError, match=self.np_err_msg(func)):
            func(a, c, check_scalar=True)

    @pytest.mark.parametrize("dtype", ["int64", "float64"])
    def test_assert_close_tolerance(self, dtype: str, xp: ArrayNamespace):
        a = xp.asarray([100], dtype=getattr(xp, dtype))
        b = xp.asarray([102], dtype=getattr(xp, dtype))

        with pytest.raises(AssertionError, match="Mismatched elements"):
            assert_close(a, b)

        assert_close(a, b, rtol=0.03)
        with pytest.raises(AssertionError, match="Mismatched elements"):
            assert_close(a, b, rtol=0.01)

        assert_close(a, b, atol=3)
        with pytest.raises(AssertionError, match="Mismatched elements"):
            assert_close(a, b, atol=1)

    def test_assert_less(self, xp: ArrayNamespace):
        assert_less(xp.asarray(-1), xp.asarray(0))
        assert_less(xp.asarray([1, 2]), xp.asarray([2, 3]))
        with pytest.raises(AssertionError, match="Mismatched elements"):
            assert_less(xp.asarray([1, 1]), xp.asarray([2, 1]))

    @pytest.mark.parametrize(
        "func", [assert_equal, assert_close, assert_less, assert_close_nulp]
    )
    @pytest.mark.skip_xp_backend(Backend.SPARSE, reason="index by sparse array")
    @pytest.mark.skip_xp_backend(Backend.ARRAY_API_STRICTEST, reason="boolean indexing")
    def test_none_shape(self, xp: ArrayNamespace, func: Callable[..., None]):
        """On Dask and other lazy backends, test that a shape with NaN's or None's
        can be compared to a real shape.
        """
        # actual has shape=(None, )
        a = xp.asarray([1] if func is assert_less else [2])
        a = a[a > 0]

        func(a, xp.asarray([2]))
        with pytest.raises(AssertionError, match="shapes do not match"):
            func(a, xp.asarray(2))
        with pytest.raises(AssertionError, match="shapes do not match"):
            func(a, xp.asarray([2, 3]))
        with pytest.raises(AssertionError, match=self.np_err_msg(func)):
            func(a, xp.asarray([0]))

        # desired has shape=(None, )
        a = xp.asarray([3] if func is assert_less else [2])
        a = a[a > 0]

        func(xp.asarray([2]), a)
        with pytest.raises(AssertionError, match="shapes do not match"):
            func(xp.asarray(2), a)
        with pytest.raises(AssertionError, match="shapes do not match"):
            func(xp.asarray([2, 3]), a)
        with pytest.raises(AssertionError, match=self.np_err_msg(func)):
            func(xp.asarray([4]), a)

    @pytest.mark.parametrize(
        "func", [assert_equal, assert_close, assert_less, assert_close_nulp]
    )
    def test_device(
        self, xp: ArrayNamespace, device: Device, func: Callable[..., None]
    ):
        a = xp.asarray([1] if func is assert_less else [2], device=device)
        b = xp.asarray([2], device=device)
        c = xp.asarray([2, 2], device=device)

        func(a, b)
        with pytest.raises(AssertionError, match="shapes do not match"):
            func(a, c)
        # This is normally performed by np.testing.assert_array_equal etc.
        # but in case of torch device='meta' we have to do it manually
        with pytest.raises(AssertionError, match="sizes do not match"):
            func(a, c, check_shape=False)

    def test_assert_close_nulp(self, xp: ArrayNamespace):
        a = xp.asarray([1.0, 1e-10], dtype=xp.float64)
        b = xp.asarray([1.0 + 2**-52, 1e-10], dtype=xp.float64)

        assert_close_nulp(a, a, nulp=0)

        assert_close_nulp(a, b, nulp=2)
        assert_close_nulp(a, b, nulp=1)
        with pytest.raises(AssertionError, match="not equal to 0 ULP"):
            assert_close_nulp(a, b, nulp=0)

        c = xp.asarray([1.0 + 2 * 2**-52, 1e-10], dtype=xp.float64)

        assert_close_nulp(a, c, nulp=3)
        assert_close_nulp(a, c, nulp=2)
        with pytest.raises(AssertionError, match="not equal to 1 ULP"):
            assert_close_nulp(a, c)

        d = xp.asarray([1.0, 1e-10 + 5 * np.spacing(1e-10)], dtype=xp.float64)
        assert_close_nulp(a, d, nulp=6)
        assert_close_nulp(a, d, nulp=5)

        with pytest.raises(AssertionError, match="not equal to 4 ULP"):
            assert_close_nulp(a, d, nulp=4)


def good_lazy(x: Array) -> Array:
    """A function that behaves well in Dask and jax.jit"""
    return x * 2.0


def non_materializable(x: Array) -> Array:
    """
    This function materializes the input array, so it will fail when wrapped in jax.jit
    and it will trigger an expensive computation in Dask.
    """
    xp = array_namespace(x)
    # Crashes inside jax.jit
    # On Dask, this triggers two computations of the whole graph
    if xp.any(x < 0.0) or xp.any(x > 10.0):
        msg = "Values must be in the [0, 10] range"
        raise ValueError(msg)
    return x


def non_materializable2(x: Array) -> Array:
    return non_materializable(x)


def non_materializable3(x: Array) -> Array:
    return non_materializable(x)


def non_materializable4(x: Array) -> Array:
    return non_materializable(x)


def non_materializable5(x: Array) -> Array:
    return non_materializable(x)


lazy_xp_function(good_lazy)
# Works on JAX and Dask
lazy_xp_function(non_materializable2, jax_jit=False, allow_dask_compute=2)
lazy_xp_function(non_materializable3, jax_jit=False, allow_dask_compute=True)
# Works on JAX, but not Dask
lazy_xp_function(non_materializable4, jax_jit=False, allow_dask_compute=1)
# Works neither on Dask nor JAX
lazy_xp_function(non_materializable5)


def test_lazy_xp_function(xp: ArrayNamespace):
    x = xp.asarray([1.0, 2.0])

    assert_equal(good_lazy(x), xp.asarray([2.0, 4.0]))
    # Not wrapped
    assert_equal(non_materializable(x), xp.asarray([1.0, 2.0]))
    # Wrapping explicitly disabled
    assert_equal(non_materializable2(x), xp.asarray([1.0, 2.0]))
    assert_equal(non_materializable3(x), xp.asarray([1.0, 2.0]))

    if is_jax_namespace(xp):
        assert_equal(non_materializable4(x), xp.asarray([1.0, 2.0]))
        with pytest.raises(
            TypeError, match="Attempted boolean conversion of traced array"
        ):
            _ = non_materializable5(x)  # Wrapped

    elif is_dask_namespace(xp):
        with pytest.raises(
            AssertionError,
            match=r"dask\.compute.* 2 times, but only up to 1 calls are allowed",
        ):
            _ = non_materializable4(x)
        with pytest.raises(
            AssertionError,
            match=r"dask\.compute.* 1 times, but no calls are allowed",
        ):
            _ = non_materializable5(x)

    else:
        assert_equal(non_materializable4(x), xp.asarray([1.0, 2.0]))
        assert_equal(non_materializable5(x), xp.asarray([1.0, 2.0]))


def static_params(x: Array, n: int, flag: bool = False) -> Array:
    """Function with static parameters that must not be jitted"""
    if flag and n > 0:  # This fails if n or flag are jitted arrays
        return x * 2.0
    return x * 3.0


lazy_xp_function(static_params)


def test_lazy_xp_function_static_params(xp: ArrayNamespace):
    x = xp.asarray([1.0, 2.0])
    assert_equal(static_params(x, 1), xp.asarray([3.0, 6.0]))
    assert_equal(static_params(x, 1, True), xp.asarray([2.0, 4.0]))
    assert_equal(static_params(x, 1, False), xp.asarray([3.0, 6.0]))
    assert_equal(static_params(x, 0, False), xp.asarray([3.0, 6.0]))
    assert_equal(static_params(x, 1, flag=True), xp.asarray([2.0, 4.0]))
    assert_equal(static_params(x, n=1, flag=True), xp.asarray([2.0, 4.0]))


def test_lazy_xp_function_deprecated_static_argnames():
    with pytest.warns(DeprecationWarning, match="static_argnames"):
        lazy_xp_function(static_params, static_argnames=["flag"])  # type: ignore[arg-type]  # pyright: ignore[reportArgumentType]
    with pytest.warns(DeprecationWarning, match="static_argnums"):
        lazy_xp_function(static_params, static_argnums=[1])  # type: ignore[arg-type]  # pyright: ignore[reportArgumentType]


try:
    # Test an arbitrary Cython ufunc (@cython.vectorize).
    # When SCIPY_ARRAY_API is not set, this is the same as
    # scipy.special.erf.
    from rsscipy.special._ufuncs import erf  # type: ignore[import-untyped]

    lazy_xp_function(erf)
except ImportError:
    erf = None


@pytest.mark.skip_xp_backend(Backend.TORCH_GPU, reason="device->host copy")
@pytest.mark.skip_xp_backend(Backend.MPARRAY, reason="mparray lacks __array_ufunc__")
@pytest.mark.filterwarnings("ignore:__array_wrap__:DeprecationWarning")  # PyTorch
def test_lazy_xp_function_cython_ufuncs(xp: ArrayNamespace, library: Backend):
    pytest.importorskip("scipy")
    assert erf is not None
    x = xp.asarray([6.0, 7.0])
    if library.like(Backend.ARRAY_API_STRICT, Backend.JAX):
        # array-api-strict arrays are auto-converted to NumPy
        # which results in an assertion error for mismatched namespaces
        # eager JAX arrays are auto-converted to NumPy in eager JAX
        # and fail in jax.jit (which lazy_xp_function tests here)
        with pytest.raises((TypeError, AssertionError)):
            assert_equal(cast(Array, erf(x)), xp.asarray([1.0, 1.0]))
    else:
        # CuPy, Dask and sparse define __array_ufunc__ and dispatch accordingly
        # note that when sparse reduces to scalar it returns a np.generic, which
        # would make assert_equal fail.
        assert_equal(cast(Array, erf(x)), xp.asarray([1.0, 1.0]))


class A:
    def __init__(self, x: Array):
        xp = array_namespace(x)
        self._xp: ArrayNamespace = xp
        self.x: Any = np.asarray(x)

    def f(self, y: Array) -> Array:
        return self._xp.asarray(np.matmul(self.x, np.asarray(y)))

    def g(self, y: Array, z: Array) -> Array:
        return self.f(y) + self.f(z)

    def h(self, y: Array) -> bool:
        return bool(self._xp.any(y))


class B(A):
    @override
    def __init__(self, x: Array):  # pyright: ignore[reportMissingSuperCall]
        xp = array_namespace(x)
        self._xp: ArrayNamespace = xp
        self.x: Any = xp.asarray(x)

    @override
    def f(self, y: Array) -> Array:
        return self._xp.matmul(self.x, y)

    @staticmethod
    def k(y: Array) -> "B":
        return B(2.0 * y)

    @staticmethod
    def j(y: Array) -> "B":
        xp = array_namespace(y)
        y = xp.asarray(y)
        if bool(xp.any(y)):
            return B(y)
        return B(y + 1.0)

    @classmethod
    def w(cls, y: Array) -> "B":
        xp = array_namespace(y)
        y = xp.asarray(y)
        if bool(xp.any(y)):
            return B(y)
        return B(y + 1.0)


@final
class eager:
    # this needs to be a staticmethod to appease the type checker
    non_materializable5 = staticmethod(non_materializable5)


lazy_xp_function((B, "g"))
lazy_xp_function((B, "h"))
lazy_xp_function((B, "k"))
lazy_xp_function((B, "j"))
lazy_xp_function((B, "w"))


class TestLazyXpFunctionClasses:
    def test_parent_method_not_tagged(self):
        assert hasattr(B.g, "_lazy_xp_function")
        assert not hasattr(A.g, "_lazy_xp_function")

    @pytest.mark.skip_xp_backend(Backend.SPARSE, reason="converts to NumPy")
    @pytest.mark.skip_xp_backend(Backend.CUPY, reason="converts to NumPy")
    @pytest.mark.skip_xp_backend(Backend.JAX_GPU, reason="converts to NumPy")
    @pytest.mark.skip_xp_backend(Backend.TORCH_GPU, reason="converts to NumPy")
    @pytest.mark.skip_xp_backend(Backend.MPARRAY, reason="precision loss")
    def test_lazy_xp_function_classes(self, xp: ArrayNamespace, library: Backend):
        x = xp.asarray([1.1, 2.2, 3.3])
        y = xp.asarray([1.0, 2.0, 3.0])
        foo = A(x)
        bar = B(x)

        if library.like(Backend.JAX):
            with pytest.raises(
                TypeError, match="Attempted boolean conversion of traced array"
            ):
                assert bar.h(y)

        assert foo.h(y)

    def test_static_methods_preserved(self, xp: ArrayNamespace):
        # Tests that static methods stay static methods when
        # lazy_xp_function is applied.
        x = xp.asarray([1.1, 2.2, 3.3])
        foo = B(x)
        bar = foo.k(x)
        assert_equal(bar.x, 2.0 * foo.x)

    @pytest.mark.skip_xp_backend(Backend.DASK, reason="calls dask.compute()")
    def test_static_methods_wrapped(self, xp: ArrayNamespace, library: Backend):
        x = xp.asarray([1.1, 2.2, 3.3])
        foo = B(x)

        if library.like(Backend.JAX):
            with pytest.raises(
                TypeError, match="Attempted boolean conversion of traced array"
            ):
                assert isinstance(foo.j(x), B)
        else:
            assert isinstance(foo.j(x), B)

    @pytest.mark.skip_xp_backend(Backend.DASK, reason="calls dask.compute()")
    def test_class_methods_wrapped(self, xp: ArrayNamespace, library: Backend):
        x = xp.asarray([1.1, 2.2, 3.3])
        if library.like(Backend.JAX):
            with pytest.raises(
                TypeError, match="Attempted boolean conversion of traced array"
            ):
                assert isinstance(B.w(x), B)
        else:
            assert isinstance(B.w(x), B)

    def test_circumvention(self, xp: ArrayNamespace):
        x = xp.asarray([1.0, 2.0])
        y = eager.non_materializable5(x)
        assert_equal(y, x)


def dask_raises(x: Array) -> Array:
    def _raises(x: Array) -> Array:
        # Test that map_blocks doesn't eagerly call the function;
        # dtype and meta should be sufficient to skip the trial run.
        assert x.shape == (3,)
        msg = "Hello world"
        raise ValueError(msg)

    return x.map_blocks(_raises, dtype=x.dtype, meta=x._meta)  # type: ignore[attr-defined]  # pyright: ignore[reportAttributeAccessIssue]


lazy_xp_function(dask_raises)


def test_lazy_xp_function_eagerly_raises(da: ArrayNamespace):
    """Test that the pattern::

        with pytest.raises(Exception):
            func(x)

    works with Dask, even though it normally wouldn't as we're disregarding the func
    output so the graph would not be ordinarily materialized.
    lazy_xp_function contains ad-hoc code to materialize and reraise exceptions.
    """
    x = da.arange(3)
    with pytest.raises(ValueError, match="Hello world"):
        _ = dask_raises(x)


class Wrapper:
    """Trivial opaque wrapper. Must be pickleable."""

    x: Array

    def __init__(self, x: Array):
        self.x = x


def check_opaque_wrapper(w: Wrapper, xp: ArrayNamespace) -> Wrapper:
    assert isinstance(w, Wrapper)
    assert array_namespace(w.x) == xp
    return Wrapper(w.x + 1)


lazy_xp_function(check_opaque_wrapper)


def test_lazy_xp_function_opaque_wrappers(xp: ArrayNamespace):
    """
    Test that function input and output can be wrapped into arbitrary
    serializable Python objects, even if jax.jit does not support them.
    """
    x = xp.asarray([1, 2])
    xp2 = array_namespace(x)  # Revert NUMPY_READONLY to array_api_compat.numpy
    res = check_opaque_wrapper(Wrapper(x), xp2)
    assert_equal(res.x, xp.asarray([2, 3]))


def test_lazy_xp_function_opaque_wrappers_eagerly_raise(da: ArrayNamespace):
    """
    Like `test_lazy_xp_function_eagerly_raises`, but the returned object is
    wrapped in an opaque wrapper.
    """
    x = da.arange(3)
    with pytest.raises(ValueError, match="Hello world"):
        _ = Wrapper(dask_raises(x))


def check_recursive(x: list[object]) -> list[object]:
    assert isinstance(x, list)
    assert x[1] is x
    y: list[object] = [cast(Array, x[0]) + 1]
    y.append(y)
    return y


lazy_xp_function(check_recursive)


def test_lazy_xp_function_recursive(xp: ArrayNamespace):
    """Test that inputs and outputs can be recursive data structures."""
    x: list[object] = [xp.asarray([1, 2])]
    x.append(x)
    y = check_recursive(x)
    assert isinstance(y, list)
    assert_equal(cast(Array, y[0]), xp.asarray([2, 3]))
    assert y[1] is y


wrapped = ModuleType("wrapped")
naked = ModuleType("naked")


def f(x: Array) -> Array:
    xp = array_namespace(x)
    # Crash in jax.jit and trigger compute() on Dask
    if not xp.all(x):
        msg = "Values must be non-zero"
        raise ValueError(msg)
    return x


wrapped.f = f  # type: ignore[attr-defined]  # pyright: ignore[reportAttributeAccessIssue]
naked.f = f  # type: ignore[attr-defined]  # pyright: ignore[reportAttributeAccessIssue]
del f


lazy_xp_function(wrapped.f)
lazy_xp_modules = [wrapped]


def test_lazy_xp_modules(xp: ArrayNamespace, library: Backend):
    x = xp.asarray([1.0, 2.0])
    y = naked.f(x)
    assert_equal(y, x)

    if library.like(Backend.JAX):
        with pytest.raises(
            TypeError, match="Attempted boolean conversion of traced array"
        ):
            wrapped.f(x)
    elif library.like(Backend.DASK):
        with pytest.raises(AssertionError, match=r"dask\.compute"):
            wrapped.f(x)
    else:
        y = wrapped.f(x)
        assert_equal(y, x)


def test_patch_lazy_xp_functions_deprecated_monkeypatch(
    request: pytest.FixtureRequest, monkeypatch: pytest.MonkeyPatch
):
    xp = pytest.importorskip("dask.array")

    x = xp.asarray([1.0, 2.0])
    y = non_materializable5(x)
    assert_equal(y, x)

    with pytest.warns(DeprecationWarning, match="`monkeypatch` parameter"):
        _ = patch_lazy_xp_functions(request, monkeypatch, xp=xp)

    with pytest.raises(AssertionError, match=r"dask\.compute.* 1 times"):
        _ = non_materializable5(x)

    monkeypatch.undo()
    y = non_materializable5(x)
    assert_equal(y, x)


def my_iter(x: Array) -> Iterator[Array]:
    yield x[0, :]
    yield x[1, :]


lazy_xp_function(my_iter)


def test_patch_lazy_xp_functions_iter(xp: ArrayNamespace):
    x = xp.asarray([[1.0, 2.0], [3.0, 4.0]])
    it = my_iter(x)

    assert isinstance(it, Iterator)
    assert_equal(next(it), x[0, :])
    assert_equal(next(it), x[1, :])
    with pytest.raises(StopIteration):
        _ = next(it)


def test_import_dependencies():
    _ = sys.modules.pop("numpy", None)
    _ = sys.modules.pop("pytest", None)
    _ = sys.modules.pop("array_api_extra", None)

    import array_api_extra  # pyright: ignore[reportUnusedImport]
    import array_api_extra.testing  # noqa: F401  # pyright: ignore[reportUnusedImport]
    from array_api_extra.testing import (
        lazy_xp_function,  # noqa: F401  # pyright: ignore[reportUnusedImport]
    )

    assert "numpy" not in sys.modules
    assert "pytest" not in sys.modules
